﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QueuingProgram
{
    public partial class ServingForm : Form
    {
        public ServingForm()
        {
            InitializeComponent();
            this.CenterToScreen();

            lblServing.Text = CashierClass.CashierQueue.Peek();
        }
    }
}
