﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Manually_Throwing_Custom_Exception
{


    public partial class Inventory : Form
    {
        private string _ProductName, _Category, _ManufacturingDate, _ExpirationDate, _Description;
        private int _Quantity;
        private double _SellingPrice;
        private BindingSource BindSource;
        private BindingList<ProductClass> showProductList;
        public new string ProductName(string PrName)
        {
            if (!Regex.IsMatch(PrName, @"^[a-zA-z]+$"))
            {
                _ProductName = PrName;
            }
            return _ProductName;
        }


       
        public Inventory()
        {
            InitializeComponent();
            BindSource = new BindingSource();
            showProductList = new BindingList<ProductClass>();
            BindSource.DataSource = showProductList;
        }
        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            {
                _ProductName = ProductName(txtProductName.Text);
                _Category = cbCategory.Text;
                _ManufacturingDate = dtPickerMfgDate.Value.ToString("yyyy-MM-dd");
                _ExpirationDate = dtPickerExpDate.Value.ToString("yyyy-MM-dd");
                _Description = richTxtDescription.Text;
               _Quantity = Quantity(txtQuantity.Text);
                _SellingPrice = SellingPrice(txtSellPrice.Text);
                showProductList.Add(new ProductClass(_ProductName, _Category, _ManufacturingDate, _ExpirationDate, _SellingPrice ,_Quantity,_Description));
                gridViewProductList.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                gridViewProductList.DataSource = showProductList;
            }
        }



        public int Quantity(string qty)
        {
            if(!Regex.IsMatch(qty,@"^[0-9]"))
            {
                _Quantity = Int32.Parse(qty);
            }
            return Convert.ToInt32(qty);
        }

        public double SellingPrice(string price)
        {
            if (!Regex.IsMatch(price.ToString(),@"^(\d*\.)?\d+$"))
            {
                _SellingPrice = double.Parse(price);
            }
            return Convert.ToDouble(price);
        }


        private void Inventory_Load(object sender, EventArgs e)
        {
            ArrayList ListOfProductCategory = new ArrayList();
            ListOfProductCategory.Add("Beverages");
            ListOfProductCategory.Add("Bread/Bakery");
            ListOfProductCategory.Add("Canned/Jarred Goods");
            ListOfProductCategory.Add("Dairy");
            ListOfProductCategory.Add("Frozen Goods");
            ListOfProductCategory.Add("Meat");
            ListOfProductCategory.Add("PersonalCare");
            ListOfProductCategory.Add("Other");

            foreach(string LopC in ListOfProductCategory)
            {
                cbCategory.Items.Add(LopC);
            }
        }
        


        }
    }

